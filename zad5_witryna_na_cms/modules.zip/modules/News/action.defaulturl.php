<?php
if (!isset($gCms)) exit;

$this->DoAction('detail', $id, $params, $returnid);


?>
